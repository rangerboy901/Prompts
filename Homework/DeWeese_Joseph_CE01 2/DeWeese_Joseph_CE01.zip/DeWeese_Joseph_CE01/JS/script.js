alert("My Javascript File is Connected Properly");
console.log("I can display text in the console!");